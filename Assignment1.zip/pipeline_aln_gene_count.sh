#!/bin/bash
path=$(pwd)                       #declaring current working directory
MY_FILE="$path"     

###The input files & locations
fqfiles="/localdisk/data/BPSM/Assignment1/fastq/fqfiles"
fastq="/localdisk/data/BPSM/Assignment1/fastq"
genome="/localdisk/data/BPSM/Assignment1/Tbb_genome/Tb927_genome.fasta.gz" 
bed_file="/localdisk/data/BPSM/Assignment1/Tbbgenes.bed"

### Arranging input fasta files according to the their TYPE
##Assign types of the sample 

echo "=========================Types of Samples========================================"

##getting type of samples from fqfiles 
sample_type=$(awk '{IFS=$'\t';print $2}' /localdisk/data/BPSM/Assignment1/fastq/fqfiles | sort | uniq )
echo "$sample_type"

fqfls=FASTA_FILES                   #giving name for FASTQ files destination folder
chmod 700 ${MY_FILE}/ 			#make able to create directories and change it by the user
mkdir ${MY_FILE}/${fqfls}		#creating folder to move fastQ files

###Copying fastq files with attaching type to their file names

cd ${fastq} 			    #moving to the one of the input folders where all fastq files located
for file in ./*                     #since every sample replicates sequence has two pair of fastq file, for each pair attaching its sample typ
do
	while read num type r1 r2    #since I know the structure of files, I can divide to columns 
	do
	f="$(basename $file)"         #takes the file name from input folder
	if [ $r1 == "$f" ] 		#checking if file is a first pair of read file
	then
		cp $file ${MY_FILE}/${fqfls}/${type}_$r1	#if statement true then copy that file by attaching sample type in front of read
	elif [ $r2 == "$f" ]		#checking if file is second pair of read file		
	then
              	cp $file ${MY_FILE}/${fqfls}/${type}_$r2	#does the same thing to the second pair of the read file
	fi
	done < ${fqfiles}       #input files fqfiles with description of fasta files
done

cd ${MY_FILE}   		#getting back to out working directory

###running fastqc
echo "==================FASTQ assessment and quality check=============="

fq_out=FASTQC_OUT    			#giving name to the FASTQ OUT folder
mkdir ${MY_FILE}/${fq_out} 		#creating folder for FASTQ output
fastqc -t 12 ${MY_FILE}/${fqfls}/* -o ${MY_FILE}/${fq_out}         #this command runs fastqc for all files in FASTA_FILES
								# -t is to set threads for speeding up the process

cd ${MY_FILE}/${fq_out}   					#moving to FASTQC output folder
for file in ${MY_FILE}/${fq_out}/*.zip; do			#for every sample's .zip output folder do unzip
        unzip ${file}						
done

grep FAIL ${MY_FILE}/${fq_out}/*_fastqc/summary.txt > Q_assessment_FASTQC.txt     #from sammary text of all fasqc folder taking out lines which has a wordFAIL 

cd ${MY_FILE}

###bowtie indexing and running
echo "====================Indexing the Reference Genome========================"

genome_file=$(basename "$genome")                #getting the name of input genome_fasta file excluding path information
gn_name=dbGENOME
mkdir ${MY_FILE}/${gn_name}			#creating directory for genome database
cp $genome ${MY_FILE}/${gn_name}/${genome_file}	#copying genome_fasta file to our working directory 
gunzip ${MY_FILE}/${gn_name}/${genome_file}		#unzipping fasta.gz file, one of the reason of miving this file to this directory is unzipping	
gn_n=${genome_file/.gz/}				#name of the unzipped file 
gn_idx=${genome_file/_genome.fasta.gz/}		#for calling index file will be use the first part of the genome file name
bowtie2-build --threads 40 -f ${MY_FILE}/${gn_name}/$gn_n ${MY_FILE}/${gn_name}/$gn_idx      #this command will makee genome_sequence file  into a "bowtie2" database before it can be used

echo "=====================Alignment using Bowtie2==================================="

declare -a fname_arr=()       #creating an empty array to save filenames without reads info so it was easier to call during Bowtie2 alignment

for file in ${MY_FILE}/${fqfls}/*;      #for all fastq files
do
	name=$(basename "$file")        #first take the fastq files name
	fname=${name/_[0-9].fq.gz/} 	#I want only name not the read pairs and ending part, so cutting those parts
	if [[ ! "${fname_arr[@]}" =~ "${fname}" ]];    #checking if array already has the element with the same name, since we have the same name for both pairs of files
	then
		fname_arr+=("${fname}")   #saving file names to the array if there is no other values in the array with same name
	fi	
done

bamout=BAM_OUT				#name of the BOWTIE2 output folder
mkdir ${MY_FILE}/${bamout}		#making directory for the BOWTIE output

for fname in "${fname_arr[@]}";        #for all the element in the array, where we saved our folder names without read details
do
	bowtie2 -p 60 -q -x ${MY_FILE}/${gn_name}/${gn_idx} -1 ${MY_FILE}/${fqfls}/${fname}_1.fq.gz -2 ${MY_FILE}/${fqfls}/${fname}_2.fq.gz -S ${MY_FILE}/${bamout}/${fname}.sam   				#this commond runs bowite2 with speed 60 threads, using genome_sequence got from bowtie-build and while calling the reads seperately I am using names from array and adding reads number and ending part														
	samtools view -b ${MY_FILE}/${bamout}/${fname}.sam > ${MY_FILE}/${bamout}/${fname}.bam		#converting sam output to the bam file with samtools, -b used to show that output is bam
	samtools sort -o ${MY_FILE}/${bamout}/${fname}.st.bam -@ 40 ${MY_FILE}/${bamout}/${fname}.bam       #for futher usage BAM files sorted using samtools with the speed of 40 threads, output file is sorted bam file with filename
	samtools index ${MY_FILE}/${bamout}/${fname}.st.bam      #for any case indexed bam files
#done

echo "=============================Generating gene counts data=============================="

bed_out=bed_OUT       		#name for the Bedtools output folder
mkdir ${MY_FILE}/${bed_out}	#making directory for the bedtools output

for line in $sample_type;	#for every sample type
do 	
	bedtools multicov -bams ${MY_FILE}/${bamout}/${line}_*.st.bam -bed $bed_file > ${MY_FILE}/${bed_out}/${line}.bed        #for multicov we use all bam files (from beginng in their file name sample type was attached) from every sample and generate one bed file  
done


out=RESULT                      #name for counts data output folder
mkdir ${MY_FILE}/${out}         #making directory for data count output

declare -a type_arr=()          #creating an empty array

for line in $sample_type;       #for every sample type
do
        type_arr+=("${line}")	#saving sample type into array	
        awk 'BEGIN{IFS="\t"; OFS="\t";}
        {
        sum=0; ave=0;
        for (i=7;i<=NF;i++)
                {sum += $i;}
        ave=sum/(NF-6);
        print ave;
        }' ${MY_FILE}/${bed_out}/${line}.bed >> ${MY_FILE}/${out}/${line}_gene_counts.txt                   #in bed file output counts data starts from the 7th column and till end of the fields, taking that into account we can count the sum of the gene counts data and divide the into replicate number
        awk '{IFS="\t"; OFS="\t"; print $4;}' ${MY_FILE}/${bed_out}/${line}.bed >> ${MY_FILE}/${out}/${line}_genelist.txt
done     #this one used to get gene list in the separate file  

paste ${MY_FILE}/${out}/${type_arr[0]}_genelist.txt ${MY_FILE}/${out}/*_gene_counts.txt > ${MY_FILE}/${out}/combined_genes_ave_count.txt             #all average counted gene counts are together with first sample's genelist into on file 

OFS="\t"; echo -e "Genes\t${type_arr[*]}" > header.txt                #sample type array printed tab-delimeted and saved in header file

paste ${MY_FILE}/${out}/${type_arr[0]}_genelist.txt ${MY_FILE}/${out}/*_gene_counts.txt > ${MY_FILE}/${out}/combined_genes_ave_count.txt    #putting together genelist and average gene count per sample into one file
cat header.txt ${MY_FILE}/${out}/combined_genes_ave_count.txt > ${MY_FILE}/${out}/statistical_counts_gene_expression.txt      #the header file and the count file combined are have put together into new file
rm -f header.txt			#deleting intermediate files
rm -f ${MY_FILE}/${out}/combined_genes_ave_count.txt

echo "==================The statistical mean of the counts per gene counted and displayed============="
echo "To see the output open RESULT/statistical_counts_gene_expression.txt"
echo "Thank you for using my pipeline! See you again!"
